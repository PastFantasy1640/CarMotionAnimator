/////////////////////////////////////////////////////
//[Module name]
//
//Copyright (c) 2017 Shotaro Shirao
//
//This software is released under the MIT License.
//http://opensource.org/licenses/mit-license.php
/////////////////////////////////////////////////////

#pragma once
#ifndef CMA__HPP_
#define CMA__HPP_

namespace cma {

/** ___replace___ CLASS
 * ����
 */
class ___replace___{
public:
	//////////////////////////////
	// PUBLIC MEMBER CONSTANT
	//////////////////////////////


	//////////////////////////////
	// PUBLIC MEMBER VALIABLES
	//////////////////////////////
	
	
	//////////////////////////////
	// PUBLIC MEMBER FUNCTION
	//////////////////////////////

	/** Constructor
	 */	
	___replace___();

	/** Destructor
	 */
	~___replace___();

protected:

private:

};

};

#endif //end of include guard
